#!/bin/bash

echo "some devcloud content" > /tmp/dev.txt
